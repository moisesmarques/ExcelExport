﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelExport
{
    public class Cell
    {
        public string r { get; set; }
        public string t { get; set; }
        public string Valor { get; set; }
    }
}

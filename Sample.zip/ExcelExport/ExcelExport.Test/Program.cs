﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelExport.Test
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);

            var data = new DataTable();
            data.Columns.Add(new DataColumn("Nome"));
            data.Columns.Add(new DataColumn("Valor", typeof(double)));            
            data.Rows.Add("Cruze", 98000.55);
            data.Rows.Add("Jetta", 86000.10);
            data.Rows.Add("Civic", 105000.75);
            data.Rows.Add("Focus", 78000.90);

            byte[] bytes = ExcelExport.Exportador.Exportar(data, string.Concat(path, "\\", "Pasta1.xlsx"), new[] { "Nome", "Valor" }, new[] { "Nome", "Valor R$" });
            
            File.WriteAllBytes("C:\\users\\moises.marques\\desktop\\teste"+DateTime.Now.Millisecond+ ".xlsx", bytes);
            
        }
    }
}
